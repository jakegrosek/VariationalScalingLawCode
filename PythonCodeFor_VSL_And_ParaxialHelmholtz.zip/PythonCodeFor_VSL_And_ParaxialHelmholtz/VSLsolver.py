# -*- coding: utf-8 -*-
"""
@author: Sophia Potoczak Bragdon 
Variational Scaling Law Solver
"""

import numpy as np
from scipy.optimize import fsolve

# import index realization class to generate Kolmogorov phase screens
from index_realization_class import index_realization_class

#%%
# Define Atmospheric Turbulence Parameters used in computing nondimensional
# constants

# Kolmogorov inner scale
innerscale =   1e-3

#Kolmogorov outer scale
outerscale =    1e2

#background index of refract
backgroundindex = 1.000273

#index structure constant and definition of index standard deviation
indexstructureconstant = 2e-8 
Cn2 = indexstructureconstant**2.0
indexvariancescaling =      1     
correlationlength = 1 

indexstandarddev = (indexstructureconstant/np.sqrt(2.0))*\
                    ((indexvariancescaling * outerscale)**(1.0/3.0))

# define wavelength and wavenumber 
wavelength =   1e-6
wavenumber = (2.0)*np.pi/wavelength


# dimensional aperture diameter used for Gaussian initial condition
aperturediameter  = 2e-2 

# dimesional domain parmeters in meters
lengthX  =  1.25
lengthY  =  1.25
propdist =  6e3

# discretization parameters
nX =   300              #number of points taken in X direction - used for phase screens
nY =   300              #number of points taken in the Y direction  - used for phase screens
nZ =   200               #number of points taken in propagation (Z) direction

# dimensional propagation direction used in effective Cn2 calculation
dZdim        = propdist/nZ
Zdim = dZdim*np.arange(0,nZ+1)


##############################################################################
# NON-DIMENSIONALIZATION
# scale the dimensional parameters for the corresponding nondimensional quantity
##############################################################################

###############################
# PROPAGATION DIRECTION SCALING 
###############################

# propagation distance scaled by Kolmogorov outerscale
comppropdist = propdist/outerscale

# nondimensional step-size in propagation direction
dZ           = comppropdist/nZ

# nondimensional array for propagation distance
Z             = dZ*np.arange(0,nZ+1)

###############################
# TRANSVERSE PLANE SCALING 
###############################

# transverse plane X-direction scaled by Kolmogorov innerscale
complengthX = lengthX/innerscale

# nondimensional step-size in X-direction
dX           = complengthX/nX

# nondimensional array for X-direction
X             = -complengthX/2.0 + dX*np.arange(0,nX)

# transverse plane Y-direction scaled by Kolmogorov innerscale
complengthY = lengthY/innerscale

# nondimensional step-size in Y-direction
dY           = complengthY/nY

# nondimensional array for Y-direction
Y             = -complengthY/2.0 + dY*np.arange(0,nY)

# Create Meshgrid for transverse plane 
meshX, meshY = np.meshgrid(X, Y)

# scale aperture diameter for Gaussian initial condition 
compaperture = aperturediameter/innerscale

# define nondimensional constants
# xi is the scaled wavenumber
xi = ((innerscale**2)*wavenumber)/outerscale      

# gamma is the scaled turbulence strength
gamma = innerscale*wavenumber*np.sqrt(indexstandarddev)  

# epsilon is ratio of innerscale and outerscale - used in phase screen generation
# epsilon needs to be a small parameter 
epsilon = innerscale/outerscale

#%%
##############################################################################
# COMPUTE EFFECTIVE CN2
##############################################################################

#number of moments in effective Cn2 calculation
M = 20 

#for RHS vec of linear system to find effective Cn2s
b = np.empty(M, dtype = np.float64)

#for coeff matrix of linear system to find eff. Cn2s
A = np.empty([M,nZ+1], dtype = np.float64)

#make coefficient matrix (A) and RHS vector (b)
for j in np.arange(M):
    for i in np.arange(nZ+1):
        A[j,i] = dZdim*(Zdim[i]**j)        
        if j > 0:
            b[j] = (Cn2/j)*propdist**(j+1)
        else:
            b[j] = Cn2*propdist

effectiveCn2 = np.linalg.lstsq(A,b)[0]


# compute effective standard deviation and effective gamma for computation
effStandardDevs = np.empty(nZ+1, dtype = np.float64)
effGammas = np.empty(nZ+1, dtype = np.float64)

for i in np.arange(nZ+1):
    effStandardDevs[i] = np.sqrt(abs(effectiveCn2[i])/2)*outerscale**(1.0/3.0)
    effGammas[i] = innerscale*wavenumber*np.sqrt(effStandardDevs[i])

#%%
##############################################################################
# Define functions used in computation of VSL solution
##############################################################################

#Gaussian ansatz that depends on beam parameters
# p contains the 10 Gaussian beam parameters
def field(p):
    A, widthX, widthY, tiltX, tiltY, positionX, positionY, focusX, focusY, phase = p  
    theta = 0.5*((widthX**2)*(meshX - positionX)**2 + (widthY**2)*(meshY - positionY)**2)
    phi = phase + tiltX*(meshX - positionX) + tiltY*(meshY - positionY) +\
               focusX*(meshX - positionX)**2 + focusY*(meshY - positionY)**2
    field = (A*np.sqrt(widthX*widthY)/np.sqrt(np.pi))*np.exp(-(theta +1j*phi))
    return field

# function to compute irradiance given vector $p$ containing Gaussian ansatz 
# parameters
def irradiance(p):
    field_data = field(p)
    irradiance = (abs(field_data))**2
    
    return irradiance


# function to compute energy given field that is size nX by nY
def Energy(stepSizeX,stepSizeY,field):
    energy = dX*dY*(np.trapz(np.trapz(np.abs(field)**2.0)))
    return energy

#define a projection for the random terms
# indexrealization is an array nX by nY
# mode is the stochastic mode in VSL governing system
def projection(indexrealization,mode, dX, dY):
    integrand = indexrealization*mode
    
    proj = dX*dY*(np.trapz(np.trapz(integrand)))
    return proj


# define RHS of ODEs- depends on array p containing beam parameters
# indexrealization is the full set of nX by nY by nZ phase screens
# index corresponds to the z-step in propagation

def f(p,params, dX, dY, meshX, meshY, indexrealization, index):
    A, widthX, widthY, tiltX, tiltY, positionX, positionY, focusX, focusY, phase = p #unpack beam parmeters in p
    backgroundindex, xi, gamma = params #unpack parameters that go into the derivatives
    
    # compute stochastic modes
    V = (widthX*widthY/np.pi)*np.exp(-((widthX**2)*(meshX-positionX)**2+(widthY**2)*(meshY-positionY)**2))
    
    V_P  = (2-(widthX**2)*(meshX - positionX)**2-(widthY**2)*(meshY-positionY)**2)*V
    V_Tx = 4*(widthX**2)*(meshX-positionX)*V
    V_Ty = 4*(widthY**2)*(meshY-positionY)*V
    V_Fx = (widthX**2)*(1-2*(widthX**2)*(meshX-positionX)**2)*V
    V_Fy = (widthY**2)*(1-2*(widthY**2)*(meshY-positionY)**2)*V
    
    # compute RHS of ODE system 
    derivs = [0,                        #amplitude
            (2/(xi*backgroundindex))*focusX*widthX, #4*focusX*widthX,           #widthX 
            (2/(xi*backgroundindex))*focusY*widthY, #4*focusY*widthY,                     #widthY  
            -backgroundindex*(gamma**2)*projection(indexrealization[index,:,:],V_Tx, dX, dY),  #tiltX
            -backgroundindex*(gamma**2)*projection(indexrealization[index,:,:],V_Ty, dX, dY),  #tiltY
            -2*tiltX,                   #positionX
            -2*tiltY,                   #positionY
            (-1/(2*backgroundindex*xi))*widthX**4+(2/(backgroundindex*xi))*focusX**2\
                + ((gamma**2)/xi)*projection(indexrealization[index,:,:], V_Fx,dX, dY), #focusX
            (-1/(2*backgroundindex*xi))*widthY**4+(2/(backgroundindex*xi))*focusY**2 \
                + ((gamma**2)/xi)*projection(indexrealization[index,:,:], V_Fy,dX, dY), #focusY
            (1/(2*backgroundindex*xi))*(widthX**2+widthY**2)-\
                ((gamma**2)/xi)*projection(indexrealization[index,:,:],V_P,dX, dY)] #piston phase
    return derivs

#%%
##############################################################################
# Define initial beam parameters- 
#the following is for a focusing Gaussian beam
###############################################################################

# beamwaist size depends on computational aperture
beamwaist = compaperture/4.0

# beamwaist location in propagation direction
beamwaistlocation = comppropdist//2 
        
# initial width parameters for a focusing Gaussian beam 
widthX0 = 4.0*np.sqrt(backgroundindex*xi)*(beamwaist)/np.sqrt(beamwaist**4+(0-beamwaistlocation)**2)
widthY0 = np.sqrt(backgroundindex*xi)*(beamwaist)/np.sqrt(beamwaist**4+(0-beamwaistlocation)**2)

# initial focus parameters for a focusing Gaussian beam
focusX0 = -(0.5*backgroundindex*xi)*(Z[0]-beamwaistlocation)/((0-beamwaistlocation)**2+beamwaist**4)
focusY0 = -(0.5*backgroundindex*xi)*(Z[0]-beamwaistlocation)/((0-beamwaistlocation)**2+beamwaist**4)

# initial piston phase for a focusing Gaussian beam
phase0  = np.arctan((Z[0] - beamwaistlocation)/(beamwaist**2.0))

# initial center of beam in transverse plane
positionX0 = 0.0
positionY0 = 0.0

# initial tip/tilt of beam
tiltX0 = 0.0
tiltY0 = 0.0

# initial amplitude
amplitude0 = 100.0

# initialize a vector to store the initial array p and the solution to VSL
psln = np.zeros([10,nZ+1])

#  store the initial beam paramters - note: order matters
psln[0,0]     = amplitude0                  
psln[1,0]     = widthX0 
psln[2,0]     = widthY0 
psln[3,0]     = tiltX0 
psln[4,0]     = tiltY0 
psln[5,0]     = positionX0  
psln[6,0]     = positionY0    
psln[7,0]     = focusX0  
psln[8,0]     = focusY0 
psln[9,0]     = phase0   

#%%
##############################################################################
# Generate Random Fields for index of refraction
# uses Kolmogorov statistics
##############################################################################
indexrealization_generator = index_realization_class(X, Y, nZ, epsilon, indexvariancescaling, indexstandarddev, correlationlength)
indexrealization = indexrealization_generator.makeindexrealizations()


#%%
##############################################################################
# Backward Euler Solver for ODE system
##############################################################################

def backwardEulerResidual(p, pold, f, dZ, index):
    # p is new update to VSL soln
    # f is function that evaluates RHS of ODEs
    # dZ is z step-size
    # znew is new z-step, znew = zold + dZ
    # index of current z-step to select phase screen
    
    res = p - pold -(dZ*np.ones(10))*f(p,params, dX, dY, meshX, meshY, indexrealization, index)
    
    return res

for i in np.arange(nZ):
    params = [backgroundindex, xi, effGammas[i]]
    pold = psln[:,i]
    
    #approximate pnew
    pnew_approx = pold + (dZ*np.ones(10))*f(pold,params, dX, dY, meshX, meshY, indexrealization, i)
    
    pnew = fsolve(backwardEulerResidual, pnew_approx, args =(pold, f, dZ, i ))
    
    psln[:,i+1] = np.copy(pnew)
    
    print('done with LSL iter'+str(i))
    
