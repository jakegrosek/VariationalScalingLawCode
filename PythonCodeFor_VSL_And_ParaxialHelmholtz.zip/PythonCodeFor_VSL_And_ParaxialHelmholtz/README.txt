This README file is for the VSLsolver.py, paraxialHelmholtzSplitStepSolver.py, and index_realization_class.py

VSLsolver: ODE solver for the variational scaling law (VSL) using the implicit Euler method 


paraxialHelmholtzSplitStepSolver: PDE solver defined using split-step method where the vacuum propagation step is completed with FFT2.
				  This solver is set-up to take a Gaussian initial condition for comparison to the VSL

VSLsolver and paraxialHelmholtzSplitStepSolver are both python scripts that can be run from command line by calling the file names. 
python3 VSLsolver.py
... or...
python3 paraxialHelmholtzSplitStepSolver.py

index_realization_class.py is a python class for the generation of Kolmogorov phase screens and it is imported in both the VSLsolver 
and paraxialHelmholtzSplitStepSolver scripts. The class and __init__ files need to be saved in the same folder as the two scripts. 

First, dimensional quantities are defined and then these quantities are scaled using the inner- and outer- scales of the atmospheric 
turbulence. The solution to the variational scaling law and the paraxial Helmholtz equation are computed in non-dimensional units.

################################
Parameters to change
################################
dimensional parameters to define in both VSLsolver and paraxialHelmholtzSplitStepSolver scripts

	innerscale: the Kolmogorov innerscale, typically 10^-3 to 10^-2 meters
	outerscale: the Kolmogorov outerscale, typically 10 - 10^3 meters
	indexstructureconstant: the square root of Cn^2, 1e-9 to 1e-7, *note* VSL requires weak turbulence which will depend on propagation
				distance. The log-amplitude variance or Rytov variance is a good measure to assess turbulence strength 
				rather than simply relying on size of index structure constant

	aperturediameter: size of aperture in meters used to define the beamwaist of the focusing Gaussian beam initial condition
	
	lengthX: size of transverse plane in x-direction measured in meters, typically 1-2 meters
	lengthY: size of transverse plane in y-direction measured in meters, typically 1-2 meters
	propdist: propgation distance in z-direction measured in meters, 10^2 to 10^4 meters
	
	nX: number of discretization points in x-direction of transverse plane
	nY: number of discretization points in y-direction of transverse plane
	nZ: number of discretization points in propagation (Z) direction

Initial Condition: formed using the vacuum focusing Gaussian beam solution to the vacuum paraxial Helmholtz equation
	
	beamwaist: nondimensional size of the beamwaist of the focusing Gaussian 
	beamwaistlocation: the location of beamwaist in propagation in non-dimensional units
	
	widthX0, widthY0: initial beam width which corresponds to a focusing Gaussian beam in vacuum
	focusX0, focusY0: initial beam focusing parameter, which corresponds to a focusing Gaussian beam in vacuum
	phase0: initial piston phase, which is defined by the focusing Gaussian beam in vacuum
	
	positionX0, positionY0: the initial position of the center of the Gaussian beam in the transverse plane
	tiltX0, tiltY0: the initial tip/tilt of the Gaussian beam
	
	amplitude0: the initial amplitude of the Gaussian beam
