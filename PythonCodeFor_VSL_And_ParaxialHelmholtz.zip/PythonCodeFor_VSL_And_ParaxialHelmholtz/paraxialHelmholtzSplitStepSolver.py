# -*- coding: utf-8 -*-
"""
Created on Sat Mar  6 16:53:41 2021

@author: Sophia Potoczak Bragdon

Split-step solver for the paraxial Helmholtz equation
this script is set-up for comparison with the solution to the
Variatonal Scaling Law 
"""

import numpy as np

# import index realization class to generate Kolmogorov phase screens
from index_realization_class import index_realization_class

#%%
# Define Atmospheric Turbulence Parameters used in computing nondimensional
# constants

# Kolmogorov inner scale
innerscale =   1e-3

#Kolmogorov outer scale
outerscale =    1e2

#background index of refract
backgroundindex = 1.000273

#index structure constant and definition of index standard deviation
indexstructureconstant = 2e-8 
Cn2 = indexstructureconstant**2.0
indexvariancescaling =      1     
correlationlength = 1 

indexstandarddev = (indexstructureconstant/np.sqrt(2.0))*\
                    ((indexvariancescaling * outerscale)**(1.0/3.0))

# define wavelength and wavenumber 
wavelength =   1e-6
wavenumber = (2.0)*np.pi/wavelength


# dimensional aperture diameter used for Gaussian initial condition
aperturediameter  = 2e-2 

# dimesional domain parmeters in meters
lengthX  =  1.25
lengthY  =  1.25
propdist =  6e3

# discretization parameters
nX =   700              #number of points taken in X direction 
nY =   700              #number of points taken in the Y direction 
nZ =   200               #number of points taken in propagation (Z) direction

# dimensional propagation direction used in effective Cn2 calculation
dZdim        = propdist/nZ
Zdim = dZdim*np.arange(0,nZ+1)


##############################################################################
# NON-DIMENSIONALIZATION
# scale the dimensional parameters for the corresponding nondimensional quantity
##############################################################################

###############################
# PROPAGATION DIRECTION SCALING 
###############################

# propagation distance scaled by Kolmogorov outerscale
comppropdist = propdist/outerscale

# nondimensional step-size in propagation direction
dZ           = comppropdist/nZ

# nondimensional array for propagation distance
Z             = dZ*np.arange(0,nZ+1)

###############################
# TRANSVERSE PLANE SCALING 
###############################

# transverse plane X-direction scaled by Kolmogorov innerscale
complengthX = lengthX/innerscale

# nondimensional step-size in X-direction
dX           = complengthX/nX

# nondimensional array for X-direction
X             = -complengthX/2.0 + dX*np.arange(0,nX)

# scaled wavenumber in X-direction
waveNumberStepSizeX = (2.0*np.pi)/complengthX
waveNumbersX        = waveNumberStepSizeX * np.arange(-nX/2.0,nX/2.0)

# transverse plane Y-direction scaled by Kolmogorov innerscale
complengthY = lengthY/innerscale

# nondimensional step-size in Y-direction
dY           = complengthY/nY

# nondimensional array for Y-direction
Y             = -complengthY/2.0 + dY*np.arange(0,nY)

# scaled wavenumber in Y-direction
waveNumberStepSizeY = (2.0*np.pi)/complengthY
waveNumbersY        = waveNumberStepSizeY * np.arange(-nY/2.0,nY/2.0)
  
# Create Meshgrid for transverse plane and for wavenumbers in transverse plane
meshX, meshY = np.meshgrid(X, Y)
meshWaveNumbersX, meshWaveNumbersY = np.meshgrid(waveNumbersX, waveNumbersY)


# scale aperture diameter for Gaussian initial condition 
compaperture = aperturediameter/innerscale

# define nondimensional constants
# xi is the scaled wavenumber
xi = ((innerscale**2)*wavenumber)/outerscale      

# gamma is the scaled turbulence strength
gamma = innerscale*wavenumber*np.sqrt(indexstandarddev)  

# epsilon is ratio of innerscale and outerscale - used in phase screen generation
# epsilon needs to be a small parameter 
epsilon = innerscale/outerscale

#%%
##############################################################################
# COMPUTE EFFECTIVE CN2
##############################################################################

#number of moments in effective Cn2 calculation
M = 20 

#for RHS vec of linear system to find effective Cn2s
b = np.empty(M, dtype = np.float64)

#for coeff matrix of linear system to find eff. Cn2s
A = np.empty([M,nZ+1], dtype = np.float64)

#make coefficient matrix (A) and RHS vector (b)
for j in np.arange(M):
    for i in np.arange(nZ+1):
        A[j,i] = dZdim*(Zdim[i]**j)        
        if j > 0:
            b[j] = (Cn2/j)*propdist**(j+1)
        else:
            b[j] = Cn2*propdist

effectiveCn2 = np.linalg.lstsq(A,b)[0]


# compute effective standard deviation and effective gamma for computation
effStandardDevs = np.empty(nZ+1, dtype = np.float64)
effGammas = np.empty(nZ+1, dtype = np.float64)

for i in np.arange(nZ+1):
    effStandardDevs[i] = np.sqrt(abs(effectiveCn2[i])/2)*outerscale**(1.0/3.0)
    effGammas[i] = innerscale*wavenumber*np.sqrt(effStandardDevs[i])

#%%
##############################################################################
# Define functions used in computation of solution to paraxial Helmholtz equation
# using a Strang splitting (or Split-Step) Scheme
##############################################################################


# compute irradiance field is an array nX by nY
def irradiance_parax(field):
    irradiance = (np.abs(field))**2
    return irradiance 

# vacuum propagation used in Split-Step computed with FFT2
# field is nX by nY array
def FFTIntegratorExact(backgroundIndex, xi, meshWaveNumbersX, meshWaveNumbersY,field,stepSize):
    fftIntegrator = np.exp(-(1.j/(2.0*backgroundIndex*xi))*\
                            (meshWaveNumbersX**2.0 + meshWaveNumbersY**2.0)*\
                            (stepSize))

    returnField = np.fft.ifft2( np.fft.ifftshift( fftIntegrator * np.fft.fftshift(np.fft.fft2(field)) ) )
    return returnField

#compute energy given nX by nY array for field
def Energy(stepSizeX,stepSizeY,field):
    energy = dX*dY*(np.trapz(np.trapz(np.abs(field)**2.0)))
    return energy

#%%
##############################################################################
# Define initial beam parameters- 
#the following is for a focusing Gaussian beam
###############################################################################

# beamwaist size depends on computational aperture
beamwaist = compaperture/4.0

# beamwaist location in propagation direction
beamwaistlocation = comppropdist//2 
       
# initial width parameters for a focusing Gaussian beam 
widthX0 = 4.0*np.sqrt(backgroundindex*xi)*(beamwaist)/np.sqrt(beamwaist**4+(0-beamwaistlocation)**2)
widthY0 = np.sqrt(backgroundindex*xi)*(beamwaist)/np.sqrt(beamwaist**4+(0-beamwaistlocation)**2)

# initial focus parameters for a focusing Gaussian beam
focusX0 = -(0.5*backgroundindex*xi)*(Z[0]-beamwaistlocation)/((0-beamwaistlocation)**2+beamwaist**4)
focusY0 = -(0.5*backgroundindex*xi)*(Z[0]-beamwaistlocation)/((0-beamwaistlocation)**2+beamwaist**4)

# initial piston phase for a focusing Gaussian beam
phase0  = np.arctan((Z[0] - beamwaistlocation)/(beamwaist**2.0))

# initial center of beam in transverse plane
positionX0 = 0.0
positionY0 = 0.0

# initial tip/tilt of beam
tiltX0 = 0.0
tiltY0 = 0.0

# initial amplitude
amplitude0 = 100.0


# Define the initial field using Gaussian ansatz from VSL
theta = 0.5* ((widthX0**2.0) * ((meshX-positionX0)**2.0) + (widthY0**2.0) * ((meshY-positionY0)**2.0))
phi   = phase0 + tiltX0 * (meshX-positionX0) + tiltY0 * (meshY-positionY0) \
                      + focusX0 * ((meshX-positionX0)**2.0) + focusY0 * ((meshY-positionY0)**2.0)
initialField  = (amplitude0*np.sqrt(widthX0*widthY0)/np.sqrt(np.pi)) * np.exp(- (theta + 1.j*phi) )

#%%
##############################################################################
# Generate Random Fields for index of refraction
# uses Kolmogorov statistics
##############################################################################
indexrealization_generator = index_realization_class(X, Y, nZ, epsilon, indexvariancescaling, indexstandarddev, correlationlength)
indexrealization = indexrealization_generator.makeindexrealizations()

#%%
##############################################################################
# set up and solve paraxial Helmholtz with split-step method
##############################################################################

# initialize array to save field and store initial condition
recordedFieldFFTIntgrator = np.empty([nX, nY,nZ+1], dtype=np.complex128)
recordedFieldFFTIntgrator[:,:,0] = initialField    

# initialize array to save irradiance corresponding to field solution 
recordedirradiance = np.zeros([nX,nY,nZ+1])
recordedirradiance[:,:,0] = irradiance_parax(initialField)

for indexZ in range(nZ):
    indexSheet = indexrealization[indexZ,:,:]
    # compt field from previous z-step
    temp = np.copy(recordedFieldFFTIntgrator[:,:,indexZ])
    
    # half z-step to correct phase with turbulence
    temp *= np.exp(1.j * ((effGammas[indexZ]**2.0)/xi) *(dZ/2.0) * indexSheet)

    # full z-step for vacuum propagation
    temp = FFTIntegratorExact(backgroundindex, xi, meshWaveNumbersX, meshWaveNumbersY,temp, dZ)
    
    # half z-step to correct phase with turbulence
    temp *= np.exp(1.j * ((effGammas[indexZ]**2.0)/xi) * (dZ/2.0) * indexSheet)

    # save updated field
    recordedFieldFFTIntgrator[:,:,indexZ+1] = np.copy(temp)  
    
    # save irradiance corresponding to current z-step field
    irrparax = irradiance_parax(recordedFieldFFTIntgrator[:,:,indexZ+1])
    recordedirradiance[:,:,indexZ+1] = np.copy(irrparax)

    print('done with parax iter'+str(indexZ))